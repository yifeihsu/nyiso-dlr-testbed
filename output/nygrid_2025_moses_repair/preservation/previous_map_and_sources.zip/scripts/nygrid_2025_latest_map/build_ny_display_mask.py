"""New York display mask that keeps schematic zone areas inside the state.

US state borders are chained from the Natural Earth admin-1 boundary lines
already used by the basemap. That file has no international boundary, so the
Canadian side is closed with coarse declared vertices along the 45th parallel,
the St. Lawrence and Niagara rivers, and through Lakes Ontario and Erie, where
the lake fill covers the mask edge. Display geometry only: no electrical or
NYISO zone boundary claim is made.
"""
from pathlib import Path
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'output/nygrid_2025_latest_map'
LINES=ROOT/'output/nygrid_2025_downstate/geography/basemap/ne_10m_admin_1_states_provinces_lines_npcc.geojson'
GEOGRAPHY=OUT/'geography_data.json'
CRS_TEXT='+proj=lcc +lat_1=40 +lat_2=45 +lat_0=42 +lon_0=-76 +datum=WGS84 +units=m +no_defs'
# Natural Earth features on the NY border, walked in order, and the vertex each walk ends on.
STATE_BORDERS=[
    ('Pennsylvania',[36],(-74.699,41.356)),
    ('New Jersey, land',[39],(-73.907,40.991)),
    ('New Jersey, Hudson River',[56],(-74.040,40.676)),
    ('New Jersey, Kill Van Kull and Arthur Kill',[3],(-74.188,40.480)),
    ('New Jersey, Raritan Bay',[54],(-73.887,40.490))]
SOUND_BORDERS=[
    ('Rhode Island, Block Island Sound',[2,1],(-72.142,41.250)),
    ('Connecticut, Long Island Sound',[55],(-73.642,41.002)),
    ('Connecticut, land',[38],(-73.481,42.055)),
    ('Massachusetts',[37],(-73.266,42.746)),
    ('Vermont',[41],(-73.351,45.005))]
START=(-79.763,42.538)
# Open water south of Long Island, from Raritan Bay to the start of the Rhode Island water boundary.
OCEAN=[(-73.70,40.40),(-72.50,40.62),(-71.70,40.95),(-71.729,41.040)]
# International boundary, coarse: 45th parallel, St. Lawrence River, Lake Ontario, Niagara River, Lake Erie.
CANADA=[(-74.00,45.003),(-74.68,44.995),(-74.80,44.980),(-75.19,44.880),(-75.50,44.700),(-75.68,44.575),
    (-75.95,44.330),(-76.10,44.230),(-76.36,44.110),(-76.80,43.750),(-77.80,43.620),(-79.06,43.300),
    (-79.06,43.265),(-79.05,43.165),(-79.07,43.080),(-79.02,43.020),(-78.98,42.960),(-78.91,42.885),START]

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def lcc():
    # Snyder (1987) ellipsoidal Lambert conformal conic, 2SP, for CRS_TEXT.
    a=6378137.0;f=1/298.257223563;e=math.sqrt(2*f-f*f)
    m=lambda p:math.cos(p)/math.sqrt(1-(e*math.sin(p))**2)
    t=lambda p:math.tan(math.pi/4-p/2)/((1-e*math.sin(p))/(1+e*math.sin(p)))**(e/2)
    p1,p2,p0,l0=(math.radians(v) for v in (40,45,42,-76))
    n=(math.log(m(p1))-math.log(m(p2)))/(math.log(t(p1))-math.log(t(p2)));F=m(p1)/(n*t(p1)**n);r0=a*F*t(p0)**n
    def project(lon,lat):
        r=a*F*t(math.radians(lat))**n;q=n*(math.radians(lon)-l0)
        return [round(r*math.sin(q)/1000,3),round(-(r0-r*math.cos(q))/1000,3)]
    return project

def walk(parts,start,end,tolerance=.03):
    # Follow touching line parts (either direction) from start to end; at a junction take the part ending nearest the goal.
    path=[start];unused=list(parts)
    while math.dist(path[-1],end)>1e-9:
        here=path[-1];options=[(math.dist(o[-1],end),math.dist(here,o[0]),p,o) for p in unused for o in (p,p[::-1]) if math.dist(here,o[0])<=tolerance]
        assert options,f'No border part continues from {here}'
        _,gap,part,oriented=min(options,key=lambda c:c[:2])
        unused.remove(part);path.extend(oriented[1:] if gap<1e-9 else oriented)
        if math.dist(path[-1],end)<=tolerance:path[-1]=end
    return path

def main():
    features=json.loads(LINES.read_text(encoding='utf-8'))['features']
    def parts(indices):
        out=[]
        for i in indices:
            g=features[i]['geometry'];out.extend([[tuple(round(v,3) for v in p) for p in part] for part in (g['coordinates'] if g['type']=='MultiLineString' else [g['coordinates']])])
        return out
    ring=[START];segments=[]
    for name,indices,end in STATE_BORDERS:
        before=len(ring);ring.extend(walk(parts(indices),ring[-1],end)[1:]);segments.append({'border':name,'naturalEarthFeatures':indices,'vertices':len(ring)-before})
    ring.extend(OCEAN);segments.append({'border':'Atlantic Ocean south of Long Island','declaredWaterVertices':len(OCEAN)})
    for name,indices,end in SOUND_BORDERS:
        before=len(ring);ring.extend(walk(parts(indices),ring[-1],end)[1:]);segments.append({'border':name,'naturalEarthFeatures':indices,'vertices':len(ring)-before})
    ring.extend(CANADA[:-1]);segments.append({'border':'Canada (45th parallel, St. Lawrence, Lake Ontario, Niagara, Lake Erie)','declaredCoarseVertices':len(CANADA)-1})
    project=lcc();geo=json.loads(GEOGRAPHY.read_text(encoding='utf-8-sig'))
    assert geo['projection']==CRS_TEXT
    errors=[math.dist(project(*n['lonlat']),n['xy']) for n in geo['nodes'] if n.get('xy') and n.get('lonlat') and not n.get('displayAnchorOf')]
    assert errors and max(errors)<.002,f'Projection mismatch {max(errors)} km'
    xy=[project(lon,lat) for lon,lat in ring]
    path='M'+'L'.join(f'{x:g},{y:g}' for x,y in xy)+'Z'
    result={'schemaVersion':1,'purpose':'display_clip_for_schematic_zone_areas_only','officialBoundaryClaim':False,
        'projection':CRS_TEXT,'xyUnits':geo['xyUnits'],'vertexCount':len(xy),'svgPath':path,
        'projectionCheck':{'method':'Snyder ellipsoidal LCC 2SP reimplemented without pyproj','nodesCompared':len(errors),'maxErrorKm':max(errors)},
        'segments':segments,'source':{'path':LINES.relative_to(ROOT).as_posix(),'sha256':sha(LINES),
            'attribution':'Natural Earth / NACIS 1:10m admin-1 boundary lines, public domain'},
        'declaredVertexNote':'Ocean and Canadian-side vertices are coarse, hand-declared and lie in water or on the international boundary; precision is a few kilometres.'}
    (OUT/'ny_display_mask.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({k:v for k,v in result.items() if k!='svgPath'},indent=2))

if __name__=='__main__':main()
