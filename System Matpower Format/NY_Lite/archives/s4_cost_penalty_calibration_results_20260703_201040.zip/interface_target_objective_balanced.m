function [J, detail] = interface_target_objective_balanced(flows, targets, options)
%INTERFACE_TARGET_OBJECTIVE_BALANCED Public-interface objective with limit scale.
%
%   Uses S_m = max(min_scale_mw, abs(target_limit_mw)) when a scaled P-32
%   interface limit is available, otherwise max(min_scale_mw, abs(target_flow)).

if nargin < 3, options = struct(); end
if ~isfield(options, 'min_scale_mw'), options.min_scale_mw = 500; end
if ~isfield(options, 'w_F'), options.w_F = 1; end

rows = table();
J = 0;
for k = 1:height(targets)
    name = string(targets.interface_name(k));
    idx = find(strcmp({flows.interface_name}, char(name)), 1);
    if ismember('target_limit_mw', targets.Properties.VariableNames)
        limit_value = targets.target_limit_mw(k);
    else
        limit_value = NaN;
    end
    if isempty(idx)
        lite_flow = NaN;
        residual = NaN;
        scale = NaN;
        term = 1e5;
    else
        lite_flow = flows(idx).flow_mw;
        target_flow = targets.target_flow_mw(k);
        if isfinite(limit_value) && limit_value > 0
            scale = max(options.min_scale_mw, abs(limit_value));
        else
            scale = max(options.min_scale_mw, abs(target_flow));
        end
        residual = lite_flow - target_flow;
        term = options.w_F * (residual / scale)^2;
    end
    J = J + term;
    rows = [rows; table(name, lite_flow, targets.target_flow_mw(k), ... %#ok<AGROW>
        limit_value, residual, scale, term, ...
        'VariableNames', {'interface_name','lite_flow_mw','target_flow_mw', ...
        'target_limit_mw','residual_mw','scale_mw','objective_term'})];
end
detail = rows;
end
