function defs = ny_lite_interface_definitions(mpc)
%NY_LITE_INTERFACE_DEFINITIONS Build PF/PT-metered reduced interface sets.
%   Each branch is metered at the source side of the positive direction.

if nargin < 1 || isempty(mpc), mpc=npcc_ny_lite_v2_topology; end
mpc=attach_nyiso_zone_metadata(mpc);
BR_STATUS=11;
if isfield(mpc.userdata,'ny_lite') && isfield(mpc.userdata.ny_lite,'original_branch_count')
    original_count=mpc.userdata.ny_lite.original_branch_count;
else
    original_count=size(mpc.branch,1);
end

specs={ ...
 'Moses_South','Moses_South','D-E','D','E','D_to_E'; ...
 'Central_East','Central_East','E-F','E','F','E_to_F'; ...
 'Total_East_proxy','Total_East_proxy','F-G','F','G','F_to_G'; ...
 'UPNY_ConEd','UPNY_ConEd','G-H','G','H','G_to_H'; ...
 'Millwood_South','Millwood_South','H-I','H','I','H_to_I'; ...
 'Dunwoodie_South','Dunwoodie_South','I-J','I','J','I_to_J'; ...
 'ConEd_LIPA_IK','ConEd_LIPA_total','I-K','I','K','I_to_K'; ...
 'ConEd_LIPA_JK','ConEd_LIPA_total','J-K','J','K','J_to_K'};
fields={'interface_name','aggregate_name','zone_boundary','positive_direction', ...
 'branch_index','branch_from','branch_to','branch_from_name','branch_to_name', ...
 'metered_bus','metered_end','flow_column','sign','original_or_added', ...
 'candidate_name','target_source'};
rows={};
for b=1:size(mpc.branch,1)
    if size(mpc.branch,2)>=BR_STATUS && mpc.branch(b,BR_STATUS)<=0, continue; end
    fb=mpc.branch(b,1); tb=mpc.branch(b,2);
    fi=find(mpc.bus(:,1)==fb,1); ti=find(mpc.bus(:,1)==tb,1);
    fz=mpc.userdata.nyiso_physical_zone{fi}; tz=mpc.userdata.nyiso_physical_zone{ti};
    for s=1:size(specs,1)
        za=specs{s,4}; zb=specs{s,5};
        if strcmp(fz,za) && strcmp(tz,zb)
            metered=fb; mend='from'; fcol='PF';
        elseif strcmp(fz,zb) && strcmp(tz,za)
            metered=tb; mend='to'; fcol='PT';
        else
            continue;
        end
        if b<=original_count, source='original'; else, source='added'; end
        cname=candidate_for_branch(mpc,b);
        rows(end+1,:)={specs{s,1},specs{s,2},specs{s,3},specs{s,6}, ...
            b,fb,tb,bus_name(mpc,fi),bus_name(mpc,ti),metered,mend,fcol,1, ...
            source,cname,'Matched Perform flow/PTDF target preferred'}; %#ok<AGROW>
    end
end
if isempty(rows), defs=cell2struct(cell(0,numel(fields)),fields,2); else, defs=cell2struct(rows,fields,2); end
end
function name=bus_name(mpc,idx)
if isfield(mpc,'bus_name') && numel(mpc.bus_name)>=idx, name=strtrim(mpc.bus_name{idx}); else, name=sprintf('BUS_%d',mpc.bus(idx,1)); end
end
function name=candidate_for_branch(mpc,b)
name='';
if isfield(mpc.userdata,'ny_lite') && isfield(mpc.userdata.ny_lite,'added_tielines')
    a=mpc.userdata.ny_lite.added_tielines;
    for k=1:numel(a)
        if isfield(a(k),'branch_index') && a(k).branch_index==b, name=a(k).name; return; end
    end
end
end
